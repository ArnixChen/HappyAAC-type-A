#include "Arduino.h"

#define __USE_FEEDBACK__

//#define __SERIAL_DEBUG__
//#define __LA_DEBUG__

#ifdef __LA_DEBUG__
#define ON_ACK_WIRE 10
#define ON_SEND_WIRE A0
#define ON_RECVBYTE_WIRE A2
#define ON_RECVFUNC_WIRE A3
#endif

#ifndef DFPlayerMini_Arnix_cpp

#define DFPlayerMini_Arnix_cpp

#define DFPLAYER_SEND_LENGTH 10
#define SB 0x7E //start byte
#define VER 0xFF //version
#define LEN 0x6 //number of bytes after "LEN" (except for checksum data and EB)
#ifdef __USE_FEEDBACK__
#define FEEDBACK 1 //feedback requested
#else
#define FEEDBACK 0 //no feedback requested
#endif
#define EB 0xEF //end byte

#define PLAY_COMMAND 0x03
#define VOLUME_COMMAND 0x06
#define EQ_COMMAND 0x07
#define LOOP_COMMAND 0x08
#define PLAYBACK_SRC_COMMAND 0x09
#define PLAYBACK_TF 0x01
#define PLAYBACK_SLEEP 0x03

#define STANDBY_COMMAND 0x0A
#define WAKEUP_COMMAND 0x0B
#define RESET_COMMAND 0x0C
#define RESUME_COMMAND 0x0D
#define PAUSE_COMMAND 0x0E
#define FOLDER_PLAY_COMMAND 0x0F
#define STOP_COMMAND 0x16
#define PLAY_MP3_FOLDER_COMMAND 0x12
#define INSERT_ADVERT_COMMAND 0x13
//#define KPLAY_COMMAND 0x14 //for folder has thousands of files
#define QUERY_STATUS_COMMAND 0x42
#define QUERY_VOLUME_COMMAND 0x43
#define QUERY_EQ_COMMAND 0x44
#define QUERY_PLAYBACK_MODE_COMMAND 0x45
#define QUERY_FIRMWARE_VERSION_COMMAND 0x46
#define QUERY_TOTAL_FILES_TF_COMMAND 0x47
#define QUERY_TOTAL_FILES_UDISK_COMMAND 0x48
#define QUERY_TOTAL_FILES_FLASH_COMMAND 0x49
#define QUERY_FOLDER_TOTAL_FILES_COMMAND 0x4E   // Only for DFPlayer mini with non yx5200 chip
#define QUERY_TOTAL_FOLDERS_COMMAND 0x4F

#define RETURN_AN_ERROR 0x40
#define ACK_RETURN 0x41
#define STORAGE_PLUG_IN 0x3A
#define STORAGE_PULL_OUT 0x3B
#define PLAY_TF_RETURN 0x3D
#define POWERON_INIT_DONE 0x3F
#define SD_CARD_ONLINE 0x02

#define STATUS_MSB_USB_STICK 0x01
#define STATUS_MSB_SD_CARD 0x02
#define STATUS_MSB_IN_SLEEP_MODE 0x10
#define STATUS_LSB_STOPPED 0x00
#define STATUS_LSB_PLAYING 0x01
#define STATUS_LSB_PAUSED 0x02
#define STATUS_MP3_IDLE 0x0200
#define STATUS_MP3_BUSY 0x0201

#define POWERON_ONLINE_USB_STICK 0x01
#define POWERON_ONLINE_SD_CARD 0x02
#define POWERON_ONLINE_USB_STICK_AND_SD_CARD 0x03
#define POWERON_ONLINE_PC 0x04

#define STORAGE_IN_USB_STICK 0x01
#define STORAGE_IN_SD_CARD 0x02
#define STORAGE_IN_PC	0x04
#define STORAGE_OUT_USB_STICK 0x01
#define STORAGE_OUT_SD_CARD 0x02
#define STOARGE_OUT_PC 0x04

#define ERR_ON_BUSY 0x01
#define ERR_ON_CUREENTLY_SLEEP_MODE 0x02
#define ERR_ON_SERIAL_RECEVING 0x03
#define ERR_ON CHECKSUM_INCORRECT 0x04
#define ERR_ON_OUT_OF_TRACK_SCOPE 0x05
#define ERR_ON_TRACK_NOT_FOUND 0x06
#define ERR_ON_INSERTION_ERROR 0x07
#define ERR_ON_SD_READ_FAILED 0x08
#define ERR_ON_ENTERED_INTO_SLEEP_MODE 0x09

#define EQ_NORMAL 0
#define EQ_POP 1
#define EQ_ROCK 2
#define EQ_JAZZ 3
#define EQ_CLASSIC 4
#define EQ_Base 5

#define MAX_VOLUME 0x1F
#define MIN_VOLUME 0x08

class DFPlayerMini_Arnix {
 private:
  Stream* _serial;
  bool (*idleWorker)(); // return true -- abort current function, false -- do nothing
  uint8_t _volume;
  uint8_t _busyPin = 0;
  uint8_t _minVolume = MIN_VOLUME;
  uint8_t _numberOfFolders = 0;
  uint8_t _numberOfFileInFolder[100];

  uint8_t _sending[DFPLAYER_SEND_LENGTH] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  uint8_t _recving[DFPLAYER_SEND_LENGTH] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  uint8_t commandValue = 0;
  uint8_t paramMSB = 0;
  uint8_t paramLSB = 0;
  uint8_t checksumMSB = 0;
  uint8_t checksumLSB = 0;

  void _sendData();

 public:

  void begin(Stream& stream);
	void checkAllFolderFileCounts();
  void setIdleWorker(bool (*worker)());
  void setBusyPin(uint8_t busyPin);
  void setMinVolume(uint8_t volume);
  bool isBusy();
  bool isPlaying();
  bool isQueryCommand(uint8_t cmd);
  void findChecksum();
  uint8_t volume(uint8_t volume);
  uint8_t getVolume();
  uint8_t volumeUp();
  uint8_t volumeDown();
  void sleep();
  void wakeup();
  void standby();
  uint16_t reset();
	uint16_t reset(uint8_t& queryCmd);

  void loop(uint16_t fileNum);
  void play(uint16_t fileNum);
  void playFromMP3Folder(uint16_t fileNum);
  void playFromMP3FolderAndWait(uint16_t fileNum);
  void playAdvertisement(uint16_t fileNum);
  void playAndWait(uint16_t fileNum);
  void folderPlay(uint8_t folderNum, uint8_t fileNum);
  uint16_t folderPlayAndWait(uint8_t folderNum, uint8_t fileNum);

  void stop();
  //      void kplay(uint8_t folderNum, uint16_t fileNum);
  void EQSelect(uint8_t setting);
  void pause();
  void resume();
  uint16_t status();
  uint16_t firmwareVersion();
  uint16_t folderFileCounts(uint8_t folderNum); // Only for DFPlayer mini with non yx5200 chip
  uint16_t totalFiles();
  uint16_t totalFolders();
  uint16_t sendData();
  uint16_t recvData();
  uint16_t recvData(uint8_t &queryCmd);
};

#endif

