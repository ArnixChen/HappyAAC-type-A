#include "DFPlayerMini_Arnix.h"

#define maskPin 0

#ifdef __LA_DEBUG__
void laBegin(uint8_t laPin) {
	if (laPin == maskPin)
		return;
  pinMode(laPin, OUTPUT);
  digitalWrite(laPin, LOW);
  digitalWrite(laPin, HIGH);
  delay(10);
  digitalWrite(laPin, LOW);
}

void laSignature(uint8_t laPin, uint8_t delayPeriod, uint8_t repeatTimes=1) {
	if (laPin == maskPin)
		return;
  for (uint8_t i=0; i<repeatTimes; i++) {
    digitalWrite(laPin, LOW);delay(delayPeriod);
    digitalWrite(laPin, HIGH);delay(delayPeriod);
  }
}
#endif

void DFPlayerMini_Arnix::begin(Stream &stream) {
  _serial = &stream;
  uint8_t queryCmd;
  unsigned long initTime = millis();
  uint16_t result;

#ifdef __LA_DEBUG__
  pinMode(ON_RECVBYTE_WIRE, OUTPUT); // for test begin
  pinMode(ON_RECVFUNC_WIRE, OUTPUT); // for RecvFunction
  pinMode(ON_ACK_WIRE, OUTPUT); // for Acknowledge
  pinMode(ON_SEND_WIRE, OUTPUT); // for SendData
  digitalWrite(ON_RECVBYTE_WIRE, HIGH); // when test begin turns LOW, and turns HIGH when finished
  digitalWrite(ON_RECVFUNC_WIRE, HIGH); // when recvData() begin turns LOW, and turns HIGH when finished
  digitalWrite(ON_ACK_WIRE, HIGH); // when Acknowledge check begin turns LOW, and turns HIGH when finished
  digitalWrite(ON_SEND_WIRE, HIGH); // when SendData begin turns LOW, and turns HIGH when finished
#endif

	for (uint8_t i=1; i<=99; i++) {
		_numberOfFileInFolder[i] = 0;
	}

  do {
    result = recvData(queryCmd); // See FN-M16P Embedded MP3 Audio Module Datasheet v1.0
                        // https://github.com/PowerBroker2/DFPlayerMini_Fast/blob/master/extras/FN-M16P%2BEmbedded%2BMP3%2BAudio%2BModule%2BDatasheet.pdf
                        // Section 3.5 Returned Data from Module

    if (queryCmd == STORAGE_PLUG_IN) {
    	switch(result) {
    		case STORAGE_IN_USB_STICK: // USB flash drive plugged in 
#ifdef __LA_DEBUG__
   				laSignature(0, 5, 13);
#endif
    			break;
    		case STORAGE_IN_SD_CARD: // SD card plugged in
#ifdef __LA_DEBUG__
    			laSignature(0, 6, 13);
    			goto endOfWhile;
#endif
    			break;
    		case STORAGE_IN_PC: // PC plugged in 
#ifdef __LA_DEBUG__
    			laSignature(0, 7, 13);
#endif
    			break;
    	}
		}

    if (queryCmd == POWERON_INIT_DONE) {
    	switch(result) {
    		case POWERON_ONLINE_USB_STICK: // USB flash drive online
#ifdef __LA_DEBUG__
   				laSignature(0, 5, 5);
#endif
    			break;
    		case POWERON_ONLINE_SD_CARD: // SD card online
#ifdef __LA_DEBUG__
    			laSignature(0, 6, 5);
#endif
    			goto endOfWhile;
    			break;
    		case POWERON_ONLINE_USB_STICK_AND_SD_CARD: // USB flash drive and  SD card online
#ifdef __LA_DEBUG__
    			laSignature(0, 7, 5);
#endif
    			break;
    		case POWERON_ONLINE_PC: // PC online
#ifdef __LA_DEBUG__
    			laSignature(0, 8, 5);
#endif
    			break;
    			
    		default:
#ifdef __LA_DEBUG__
    			laSignature(0, 9, 5);
#endif
    			// If module has no responding for more than 200ms, then we reset it once.
					if ((initTime != 0xFFFFFFFF) && ((millis() - initTime) > 500)) {
						initTime = 0xFFFFFFFF;
						result = reset(queryCmd);
					}
    	}
		}
    
    if (queryCmd == RETURN_AN_ERROR) {
    	switch(result) {
    		case ERR_ON_BUSY:
#ifdef __LA_DEBUG__
    			laSignature(0, 1, 8);
#endif
    			// If module has no responding for more than 200ms, then we reset it once.
					if ((initTime != 0xFFFFFFFF) && ((millis() - initTime) > 500)) {
						initTime = 0xFFFFFFFF;
						result = reset(queryCmd);
					}
    			break;
    		case ERR_ON_CUREENTLY_SLEEP_MODE:
#ifdef __LA_DEBUG__
    			laSignature(0, 2, 8);
#endif
    			break;
    		case ERR_ON_SERIAL_RECEVING:
#ifdef __LA_DEBUG__
    			laSignature(0, 3, 8);
#endif
    			break;
    		default:
#ifdef __LA_DEBUG__
    			laSignature(0, 4, 8);
#endif
    			break;
    	}
    }

//#ifdef __LA_DEBUG__
    //digitalWrite(0, LOW);
//#endif    
    delay(5);
//#ifdef __LA_DEBUG__
    //digitalWrite(0, HIGH);
//#endif    
  } while (1);
  endOfWhile:
#ifdef __LA_DEBUG__
  laSignature(10, 2, 4);
#endif
	return;
}

void DFPlayerMini_Arnix::checkAllFolderFileCounts() {
	_numberOfFolders = totalFolders();
	pinMode(17, OUTPUT);
	pinMode(30, OUTPUT);
	for (uint8_t i=1; i<=_numberOfFolders-2; i++) {
    digitalWrite(30, LOW);
    digitalWrite(17, HIGH);
		_numberOfFileInFolder[i] = folderFileCounts(i);
		digitalWrite(30, HIGH);
		digitalWrite(17, LOW);
		delay(100);
	}
}

void DFPlayerMini_Arnix::setIdleWorker(bool (*worker)()) {
  idleWorker = worker;
}

void DFPlayerMini_Arnix::setBusyPin(uint8_t busyPin) {
  _busyPin = busyPin;
  pinMode(_busyPin, INPUT);
}

bool DFPlayerMini_Arnix::isBusy() {
  if (_busyPin != 0) 
    return (digitalRead(_busyPin) == HIGH) ? true : false;
  else {
    delay(200);
    return (status() == 0x201) ? true : false;
  }
}

bool DFPlayerMini_Arnix::isPlaying() {
  delay(200);
  return (status() == 0x201) ? true : false;
}

void DFPlayerMini_Arnix::findChecksum() {
  uint16_t checksum = (~(VER + LEN + commandValue + FEEDBACK + paramMSB + paramLSB)) + 1;

  checksumMSB = checksum >> 8;
  checksumLSB = checksum & 0xFF;
}

void DFPlayerMini_Arnix::setMinVolume(uint8_t volume) {
  _minVolume = volume;
}

uint8_t DFPlayerMini_Arnix::volume(uint8_t volume) {
  volume = (volume > MAX_VOLUME) ? MAX_VOLUME : volume;
  volume = (volume < _minVolume) ? _minVolume : volume;
  commandValue = VOLUME_COMMAND;
  paramMSB = 0;
  paramLSB = volume;
  _volume = volume;

  findChecksum();
  sendData();
  return _volume;
}

uint8_t DFPlayerMini_Arnix::getVolume() {
  commandValue = QUERY_VOLUME_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  return (uint8_t) sendData();
}

uint8_t DFPlayerMini_Arnix::volumeUp() {
  return volume(_volume + 1);
}

uint8_t DFPlayerMini_Arnix::volumeDown() {
  return volume(_volume - 2);
}

void DFPlayerMini_Arnix::sleep() {
/*
  commandValue = SLEEP_COMMAND;
  paramMSB = 0;
  paramLSB = 0;*/
  commandValue = PLAYBACK_SRC_COMMAND;
  paramMSB = 0;
  paramLSB = PLAYBACK_SLEEP;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::wakeup() {
//  commandValue = WAKEUP_COMMAND;
  commandValue = PLAYBACK_SRC_COMMAND;
  paramMSB = 0;
  paramLSB = PLAYBACK_TF;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::standby() {
//  commandValue = WAKEUP_COMMAND;
  commandValue = STANDBY_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  sendData();
}

uint16_t DFPlayerMini_Arnix::reset() {
  commandValue = RESET_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  return sendData();
}

uint16_t DFPlayerMini_Arnix::reset(uint8_t& queryCmd) {
	uint16_t result;
  commandValue = RESET_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  result = sendData();
  queryCmd = _recving[0x03];
  return result;
}

void DFPlayerMini_Arnix::loop(uint16_t fileNum) {
  commandValue = LOOP_COMMAND;
  paramMSB = (fileNum >> 8) & 0xFF;
  paramLSB = fileNum & 0xFF;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::stop() {
  commandValue = STOP_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  sendData();
}

/*
  void DFPlayerMini_Arnix::kplay(uint8_t folderNum, uint16_t fileNum)
  {
  commandValue = KPLAY_COMMAND;
  paramMSB = ((folderNum & 0x0F) << 4) | ((fileNum >> 8) & 0x0F);
  paramLSB = fileNum & 0xFF;

  findChecksum();
  sendData();
  }*/

void DFPlayerMini_Arnix::EQSelect(uint8_t setting) {
  commandValue = EQ_COMMAND;
  paramMSB = 0;
  paramLSB = setting;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::pause() {
  commandValue = PAUSE_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::resume() {
  commandValue = RESUME_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  sendData();
}

uint16_t DFPlayerMini_Arnix::status() {
  commandValue = QUERY_STATUS_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  return sendData();
}

uint16_t DFPlayerMini_Arnix::firmwareVersion() {
  commandValue = QUERY_FIRMWARE_VERSION_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  return sendData();
}

uint16_t DFPlayerMini_Arnix::totalFiles() {
  commandValue = QUERY_TOTAL_FILES_UDISK_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  return sendData();
}

uint16_t DFPlayerMini_Arnix::totalFolders() {
	if (_numberOfFolders !=0)
		return (uint16_t) _numberOfFolders;

  commandValue = QUERY_TOTAL_FOLDERS_COMMAND;
  paramMSB = 0;
  paramLSB = 0;

  findChecksum();
  return sendData();
}

bool DFPlayerMini_Arnix::isQueryCommand(uint8_t cmd) {
  switch(cmd) {
    case QUERY_STATUS_COMMAND:
    case QUERY_VOLUME_COMMAND:
    case QUERY_EQ_COMMAND:
    case QUERY_PLAYBACK_MODE_COMMAND:
    case QUERY_TOTAL_FILES_TF_COMMAND:
    case QUERY_TOTAL_FILES_UDISK_COMMAND:
    case QUERY_TOTAL_FILES_FLASH_COMMAND:
    case QUERY_FOLDER_TOTAL_FILES_COMMAND:
    case QUERY_TOTAL_FOLDERS_COMMAND:
      return true;
      break;
      
    default:
      return false;
  }

}

void DFPlayerMini_Arnix::folderPlay(uint8_t folderNum, uint8_t fileNum) {
  commandValue = FOLDER_PLAY_COMMAND;
  paramMSB = folderNum & 0xFF;
  paramLSB = fileNum & 0xFF;

  findChecksum();
  sendData();
}

uint16_t DFPlayerMini_Arnix::folderPlayAndWait(uint8_t folderNum, uint8_t fileNum) {
  folderPlay(folderNum, fileNum);
  uint16_t result;
  // Wait for first finish playing response
  do {
    delay(2);

    result = recvData();
    if (_recving[0x03] == RETURN_AN_ERROR)
      return result;
  } while (_recving[0x03] != PLAY_TF_RETURN);

  //if (doneFile == (folderNum+fileNum)) { 
  // Because we can't know the serial file number is,
  // so we skip the filenumber checking
  
  delay(20); 
  // We need to wait 20ms for second finish playing response to complete its data transmission.
  // Now we can receive second response data completely.
  do {
    delay(2);

    result = recvData();
    if (_recving[0x03] == RETURN_AN_ERROR)
      return result;
  } while (_recving[0x03] != PLAY_TF_RETURN);
  return result;
}

// Only for DFPlayer mini with non yx5200 chip
uint16_t DFPlayerMini_Arnix::folderFileCounts(uint8_t folderNum){
	if (_numberOfFileInFolder[folderNum] != 0)
		return (uint16_t) _numberOfFileInFolder[folderNum];

  commandValue = QUERY_FOLDER_TOTAL_FILES_COMMAND;
  paramMSB = 0;
  paramLSB = folderNum & 0xFF;

  findChecksum();
  uint16_t result;
  result = sendData();
#ifdef __SERIAL_DEBUG__
  Serial.print("result = ");
  Serial.println(result);
#endif
  return result;
}

void DFPlayerMini_Arnix::play(uint16_t fileNum) {
  commandValue = PLAY_COMMAND;
  paramMSB = (fileNum >> 8) & 0xFF;
  paramLSB = fileNum & 0xFF;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::playFromMP3Folder(uint16_t fileNum) {
  commandValue = PLAY_MP3_FOLDER_COMMAND;
  paramMSB = (fileNum >> 8) & 0xFF;
  paramLSB = fileNum & 0xFF;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::playFromMP3FolderAndWait(uint16_t fileNum) {
  playFromMP3Folder(fileNum);

  uint16_t doneFile;
  // Wait for first finish playing response
  do {
    delay(2);

    doneFile = recvData();
    if (_recving[0x03] == RETURN_AN_ERROR)
      return;
  } while (_recving[0x03] != PLAY_TF_RETURN);
#ifdef __SERIAL_DEBUG__
  Serial.print(F("DFP::pAW doneFile="));
  Serial.print(doneFile);
  Serial.print(" (0x");
  Serial.print(doneFile, HEX);
  Serial.println(")");
#endif

  if (doneFile == fileNum) {
    delay(20); 
    // We need to wait 20ms for second finish playing response to complete its data transmission.
    // Now we can receive second response data completely.
    do {
      delay(2);

      recvData();
      if (_recving[0x03] == RETURN_AN_ERROR)
        return;
    } while (_recving[0x03] != PLAY_TF_RETURN);
  }
}

void DFPlayerMini_Arnix::playAdvertisement(uint16_t fileNum) {
  commandValue = INSERT_ADVERT_COMMAND;
  paramMSB = (fileNum >> 8) & 0xFF;
  paramLSB = fileNum & 0xFF;

  findChecksum();
  sendData();
}

void DFPlayerMini_Arnix::playAndWait(uint16_t fileNum) {
#ifdef __SERIAL_DEBUG__
  Serial.print(F("DFP::pAW fNum="));
  Serial.print(fileNum);
  Serial.print(" (0x");
  Serial.print(fileNum, HEX);
  Serial.println(")");
#endif
  play(fileNum);

  uint16_t doneFile;
  // Wait for first finish playing response
  do {
    delay(2);

    doneFile = recvData();
    if (_recving[0x03] == RETURN_AN_ERROR)
      return;
  } while (_recving[0x03] != PLAY_TF_RETURN);
#ifdef __SERIAL_DEBUG__
  Serial.print(F("DFP::pAW doneFile="));
  Serial.print(doneFile);
  Serial.print(" (0x");
  Serial.print(doneFile, HEX);
  Serial.println(")");
#endif

  if (doneFile == fileNum) {
    delay(20); 
    // We need to wait 20ms for second finish playing response to complete its data transmission.
    // Now we can receive second response data completely.
    do {
      delay(2);

      recvData();
      if (_recving[0x03] == RETURN_AN_ERROR)
        return;
    } while (_recving[0x03] != PLAY_TF_RETURN);
  }
}

void DFPlayerMini_Arnix::_sendData() {
  _sending[0] = SB;
  _sending[1] = VER;
  _sending[2] = LEN;
  _sending[3] = commandValue;
  _sending[4] = FEEDBACK;
  _sending[5] = paramMSB;
  _sending[6] = paramLSB;
  _sending[7] = checksumMSB;
  _sending[8] = checksumLSB;
  _sending[9] = EB;

  _serial->write(_sending, DFPLAYER_SEND_LENGTH);
}

uint16_t DFPlayerMini_Arnix::sendData() {

#ifdef __SERIAL_DEBUG__
  Serial.println(F("DFP: send() beg"));
#endif

#ifndef __USE_FEEDBACK__
  _sendData();
#else
  unsigned long beginTime;
  uint8_t keepCmd = commandValue;
  uint16_t recvValue = 0;
  bool isQueryCmd = false;

  // Clear old data in serial buffer  
  while (_serial->available()>0) {
    _serial->read();
  }

  isQueryCmd = isQueryCommand(keepCmd);
#ifdef __SERIAL_DEBUG__
  Serial.print("DFP: is Query Cmd:");
  Serial.println((isQueryCmd == true) ? "true" : "false");
#endif

  beginTime = millis();
  do {
    commandValue = keepCmd;
#ifdef __LA_DEBUG__
    digitalWrite(ON_SEND_WIRE, LOW);
#endif
    _sendData();

#ifdef __LA_DEBUG__
    digitalWrite(ON_ACK_WIRE, LOW);
#endif
    
    // For query-style command , we wait for responded data first
    if (isQueryCmd) {
      do {
        delay(20);
#ifdef __SERIAL_DEBUG__
  Serial.println(F("DFP: qrcv() bg"));
#endif
        recvValue = recvData();
#ifdef __SERIAL_DEBUG__
        Serial.print("DFP: recvValue=0x");
        Serial.print(recvValue, HEX);
        Serial.println();
        Serial.println(F("DFP: qrcv() ed"));
        Serial.print("DFP: _recving[0x03]=0x");
        Serial.print(_recving[0x03], HEX);
        Serial.println();
        Serial.print("DFP: keepCmd=0x");
        Serial.print(keepCmd, HEX);
        Serial.println();
#endif
        if (_recving[0x03] == keepCmd) {
#ifdef __SERIAL_DEBUG__
          Serial.println("DFP: _recving[0x03]==keepCmd!");
#endif
          return recvValue;
        } else {
        	// The goal of following codes is to keep sendData() from falling into 
        	// endless loop whenever DFPlayer mini module does not answer the querried
        	// value , just return an ACK.
        	if (_recving[0x03] == ACK_RETURN) {
#ifdef __SERIAL_DEBUG__
          	Serial.println("DFP: _recving[0x03]==ACK!");
          	Serial.println("DFP: ACK without query value returned!!");
#endif
        		return recvValue;
        	}
        }
      } while (_recving[0x03] != keepCmd);    
    }

#ifdef __LA_DEBUG__
    //digitalWrite(ON_ACK_WIRE, LOW);
#endif

    // Then we get acknowledged data
    delay(19); // We must wait 19 mini-seconds for acknowledge signals appear completely
               // This period was measured by logic analyzer graph

#ifdef __SERIAL_DEBUG__
  Serial.println(F("DFP: rcv() bg"));
#endif
    recvData();

#ifdef __SERIAL_DEBUG__
  Serial.println(F("DFP: rcv() ed"));
#endif
#ifdef __LA_DEBUG__
    digitalWrite(ON_ACK_WIRE, HIGH);
#endif

  } while ((_recving[0x03] != ACK_RETURN) && ((millis()-beginTime) < 100));
#ifdef __SERIAL_DEBUG__
  Serial.println(F("DFP: send() end"));
#endif
  
#ifdef __LA_DEBUG__
  digitalWrite(ON_SEND_WIRE, HIGH);
#endif
  if (isQueryCmd)
    return recvValue;

#endif // __USE_FEEDBACK__
  return 0;
}

uint16_t DFPlayerMini_Arnix::recvData() {
  uint8_t queryCmd = 0;
  return recvData(queryCmd);
}

uint16_t DFPlayerMini_Arnix::recvData(uint8_t &queryCmd) {
  uint8_t recvByte;
  uint8_t i = 0;
  bool dataBegin = false;

#ifdef __LA_DEBUG__
  digitalWrite(ON_RECVFUNC_WIRE, LOW);
#endif

  for (i = 0; i < 10; i++)
    _recving[i] = 0;

  // 注意：根據 SoftwareSerial 頁面的說明 https://www.arduino.cc/en/Reference/SoftwareSerial
  // 在ATmega32u4上只有這些腳位
  //  8, 9, 10, 11, 14, 15, 16 可以用來接收來自模組的資料
  // 而在 ATmega328P 上則沒有這些限制
  // 如果使用了不能用於 RX 的腳位,將使 Arduino 接收不到資料,
  // 而造成 _serial->available() 永遠回報 0 的值, 而使下面的迴圈進入條件永遠不能滿足

  while (_serial->available()) {
    if (idleWorker != NULL) {
      if (idleWorker() == true) {
      	delay(10);
        return 0;
      }
    } else {
      delay(1);
    }
#ifdef __LA_DEBUG__
    digitalWrite(ON_RECVBYTE_WIRE, LOW);
#endif
    recvByte = _serial->read();
#ifdef __LA_DEBUG__
    digitalWrite(ON_RECVBYTE_WIRE, HIGH);
#endif

    if (recvByte == SB && dataBegin == false) {
      dataBegin = true;
      i = 0;
    }

    if (dataBegin) {
      _recving[i++] = recvByte;

      if (i == 10) {
#ifdef __LA_DEBUG__
        digitalWrite(ON_RECVFUNC_WIRE, HIGH);
#endif
        queryCmd = _recving[0x03];
        delay(10);
        return ((_recving[0x05] << 8) | _recving[0x06]);
      }
    }
  }
#ifdef __LA_DEBUG__
  digitalWrite(ON_RECVFUNC_WIRE, HIGH);
#endif
	delay(10);
  return ((_recving[0x05] << 8) | _recving[0x06]);
}
