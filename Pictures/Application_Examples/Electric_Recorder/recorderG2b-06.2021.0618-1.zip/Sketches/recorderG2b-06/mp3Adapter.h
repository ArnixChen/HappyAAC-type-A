/*
  這裏的程式碼是為了便於採用不同的DFPlayer mini函式庫而準備的
  當使用別的函式庫時,只要在mp3Adapter 類別中
  將函式庫沒有的或者名稱不同的加以補充或包裝,
  就可以採用別的函式庫,而不必大改主程式
*/

#include <SoftwareSerial.h>
#include <DFPlayerMini_Arnix.h>

#define MAX_VOLUME 0x1F
#define MIN_VOLUME 0x08

class mp3Adapter : public DFPlayerMini_Arnix {

};

/*
  class mp3AdapterFast : public DFPlayerMini_Fast {
  protected:
    uint8_t _minVolume = MIN_VOLUME;

  public:
    void setMinVolume(uint8_t volume) {
      _minVolume = volume;
    }

    void playAndWait(uint16_t fileNum) {
      play(fileNum);
      while (isPlaying()) {
        delay(100);
      }
    }

    void playFromMP3FolderAndWait(uint16_t fileNum) {
      playFromMP3FolderAndWait(fileNum);
      while (isPlaying()) {
        delay(100);
      }
    }

    void folderPlay(uint8_t folderNum, uint8_t fileNum) {
      playFolder(folderNum, fileNum);
    }

    uint16_t folderPlayAndWait(uint8_t folderNum, uint8_t fileNum) {
      folderPlay(folderNum, fileNum);
      while (isPlaying()) {
        delay(100);
      }
    }

    uint16_t folderFileCounts(uint8_t folderNum) {
      // Only for DFPlayer mini with non yx5200 chip
      return (uint16_t) numTracksInFolder(folderNum);
    }

    uint16_t status() {
      return query(dfplayer::GET_STATUS_);
    }

    uint16_t totalFolders() {
      return numFolders();
    }

    uint16_t firmwareVersion() {
      return query(dfplayer::GET_VERSION);
    }

    uint8_t getVolume() {
      return (uint8_t) query(dfplayer::GET_VOL);
    }

    void standby() {
      standbyMode();
    }

    void wakeup() {
      wakeUp();
    }

    bool isBusy() {
      return isPlaying();
    }

    void volumeDown() {
      decVolume();
    }

    void volumeUp() {
      incVolume();
    }
  };

*/
