
uint16_t readVcc() {
  // Read 1.1V reference against AVcc (ATmega32U4 Datasheet P.314 011110)
  // set the reference to Vcc and the measurement to the internal 1.1V reference
#if defined(__AVR_ATmega32U4__) || defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
  ADMUX = bit(REFS0) | bit(MUX4) | bit(MUX3) | bit(MUX2) | bit(MUX1);
#elif defined (__AVR_ATtiny24__) || defined(__AVR_ATtiny44__) || defined(__AVR_ATtiny84__)
  ADMUX = bit(MUX5) | bit(MUX0);
#elif defined (__AVR_ATtiny25__) || defined(__AVR_ATtiny45__) || defined(__AVR_ATtiny85__)
  ADMUX = bit(MUX3) | bit(MUX2);
#else
  ADMUX = bit(REFS0) | bit(MUX3) | bit(MUX2) | bit(MUX1);
#endif

  delay(2); // Wait for Vref to settle
  ADCSRA |= bit(ADSC); // Start conversion
  while (bit_is_set(ADCSRA, ADSC)); // measuring

  uint8_t low  = ADCL; // must read ADCL first - it then locks ADCH
  uint8_t high = ADCH; // unlocks both

  long result = (high << 8) | low;

  result = 1125300L / result; // Calculate Vcc (in mV); 1125300 = 1.1*1023*1000
  return (uint16_t) (result + 390); // Vcc in millivolts
}

uint16_t readBatt() {
  static uint16_t vcc = 0;
  vcc = (vcc == 0) ? readVcc() : (vcc + readVcc()) / 2;
  //return vcc + 245;  // 245 is voltage drop VBAT battery and VDD
  return vcc - 122;
}

uint8_t vBattIdx = 0;
uint16_t vBatt[128];
uint16_t avgVBatt = 0;

uint16_t checkBattery(unsigned long currTime, unsigned long period) {
  static unsigned long battTime;
  uint8_t i = 0;
  float fvBatt = 0;
  static bool firstLoop = true;
  uint8_t loopEnd;

  if ((currTime - battTime) > period / 10) {
    loopEnd = (firstLoop) ? vBattIdx : 128;
    for (i = 0; i < loopEnd; i++) {
      fvBatt += vBatt[i];
    }
    avgVBatt = fvBatt / loopEnd;

    battTime = currTime;
  }

  // Update vBatt Matrix value
  vBatt[vBattIdx++] = readBatt();
  vBattIdx = (vBattIdx < 128) ? vBattIdx : 0;
  firstLoop = (firstLoop == true) ? ((vBattIdx == 0) ? false: true) : false;
  //showValue(64, 24, "bTime=", battTime);

  return avgVBatt;
}


/*
  extern Adafruit_SH1106 oled;
  void showBatteryValue() {
  float fvBattAvg = 0;
  float vDiff;
  uint8_t i = 0;

  for (i = 0; i < vBattIdx; i++) {
    fvBattAvg += vBatt[i];
  }
  fvBattAvg = (fvBattAvg / vBattIdx);

  for (i = 0; i < vBattIdx; i++) {
    vDiff = (vBatt[i] - fvBattAvg) / 8;
    oled.drawPixel(i, 44 - (int16_t)vDiff, WHITE);
  }
  showValue(0, 24, "vBatt=", fvBattAvg);
  } */
